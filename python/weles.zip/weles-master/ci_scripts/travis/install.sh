pip install --upgrade pytest pytest-cov codecov matplotlib coverage==4.4 coveralls tqdm scikit-learn
python setup.py develop
