from .Data import Data

__all__ = ["Data"]
