from .multiclass import balanced_accuracy_score

__all__ = ["balanced_accuracy_score"]
